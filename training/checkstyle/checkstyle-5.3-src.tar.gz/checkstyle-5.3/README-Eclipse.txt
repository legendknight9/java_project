To run the JUnit tests in the Eclipse, you need to set the following VM arguments:

-Dtestinputs.dir=${project_loc}\src\testinputs\com\puppycrawl\tools\checkstyle
-Dtestsrcs.dir=${project_loc}\src\tests\com\puppycrawl\tools\checkstyle
-Dcheckstyle.root=${project_loc}
